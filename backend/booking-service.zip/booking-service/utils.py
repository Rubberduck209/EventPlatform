from datetime import datetime
from zoneinfo import ZoneInfo

VN_TIMEZONE = ZoneInfo("Asia/Ho_Chi_Minh")


def now_vn() -> datetime:
    return datetime.now(VN_TIMEZONE).replace(tzinfo=None)