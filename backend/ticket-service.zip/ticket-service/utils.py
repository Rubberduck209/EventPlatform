from datetime import datetime
from zoneinfo import ZoneInfo

VN_TIMEZONE = ZoneInfo("Asia/Ho_Chi_Minh")


def now_vn() -> datetime:
    """Giờ Việt Nam hiện tại, bỏ tzinfo để lưu vào MySQL."""
    return datetime.now(VN_TIMEZONE).replace(tzinfo=None)