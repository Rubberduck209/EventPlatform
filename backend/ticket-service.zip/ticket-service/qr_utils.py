import base64
import hashlib
import hmac
import io
import json
import os

import qrcode
from dotenv import load_dotenv

load_dotenv()

QR_SECRET = os.getenv("QR_SECRET", "")
if len(QR_SECRET) < 16:
    raise RuntimeError("Thiếu QR_SECRET trong file .env (cần ít nhất 16 ký tự, nên dài ngẫu nhiên)")


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def _sign(body: str) -> str:
    """HMAC-SHA256 của nội dung QR bằng khóa QR_SECRET."""
    return hmac.new(QR_SECRET.encode("utf-8"), body.encode("ascii"), hashlib.sha256).hexdigest()


def build_qr_text(ticket_code: str, event_id: str, seat_id, owner_name: str, qr_version: int) -> str:
    """Nội dung QR: <thông tin vé base64>.<chữ ký>. Thông tin chỉ được ký, không được mã hóa."""
    data = {"c": ticket_code, "e": event_id, "s": seat_id, "o": owner_name, "v": qr_version}
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    body = _b64(raw.encode("utf-8"))
    return f"{body}.{_sign(body)}"


def verify_qr_text(qr_text: str):
    """Trả về thông tin vé nếu chữ ký đúng, ngược lại trả về None."""
    body, sep, signature = qr_text.strip().rpartition(".")
    if not sep or not body or not signature.isascii() or not body.isascii():
        return None
    if not hmac.compare_digest(_sign(body), signature):
        return None
    try:
        return json.loads(_unb64(body).decode("utf-8"))
    except ValueError:
        return None


def qr_png(text: str) -> bytes:
    code = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=8, border=4)
    code.add_data(text)
    code.make(fit=True)
    image = code.make_image(fill_color="black", back_color="white")
    output = io.BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()